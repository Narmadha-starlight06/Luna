# LUNA — Chandrayaan-2 image registration (SIH 26166)

Stack: Python, React, PyTorch, Kornia, Hugging Face, OpenCV, scikit-image, NumPy, GDAL, GeoPandas.
Architecture and workflow: `docs/ARCHITECTURE.md`.

## Run (prebuilt UI included)
```
cd backend
pip install -r requirements.txt      # torch/kornia/transformers optional; missing engines fall back to RootSIFT
uvicorn main:app --port 8000
```
Open http://localhost:8000

## Develop the UI
```
cd frontend && npm install
npm run dev        # http://localhost:5173, proxies /api to :8000
npm run build      # writes frontend/dist, served by FastAPI
```

## API
- `GET  /api/health`           engines available (torch, kornia, hf, gdal, geopandas)
- `POST /api/register`         source, reference, mode (single|multiscale), engine, gsd_source?, gsd_reference?
- `POST /api/register-multi`   sources[], labels[], reference, engine, gsd_reference?
- `GET  /api/demo`             synthetic tile with ground truth (reports true error)

Engines: `auto`, `sift`, `lightglue` (Kornia DISK+LightGlue), `loftr` (Kornia), `hf` (EfficientLoFTR, set `LUNA_HF_MODEL`).

## Verified here vs not
- Verified: RootSIFT pipeline, MAGSAC++, refinement, metrics, GeoJSON via GeoPandas, API, React build. True error 0.25-0.53 px on synthetic known-answer tiles.
- Not run here: PyTorch/Kornia/Hugging Face engines (no space for torch, weights need internet) and GDAL GeoTIFF read/write. The code is written to each library's documented API and falls back to RootSIFT with a visible note if one fails. Test them on your machine first.
- 100% accuracy is not achievable on real data; LUNA returns `failed` or `review` instead of a bad alignment.
- Planar homography model; strong relief needs a DEM-based or piecewise model.
