# LUNA architecture and workflow

```mermaid
flowchart LR
  A[React UI<br/>modes, upload, evidence] --> B[FastAPI service<br/>/api/register, /api/register-multi, /api/demo]
  B --> C[Input<br/>OpenCV decode / GDAL read<br/>source + reference]
  C --> D[Preprocess<br/>flat-field, CLAHE, structure map<br/>scikit-image histogram match]
  D --> E[AI correspondence<br/>PyTorch + Kornia LoFTR / DISK+LightGlue<br/>Hugging Face EfficientLoFTR<br/>RootSIFT fallback]
  E --> F[Match verification<br/>MAGSAC++, grid thinning, held-out RMSE]
  F --> G[Registration<br/>homography warp, scale search]
  G --> H[Sub-pixel refinement<br/>patch phase correlation, independent check points]
  H --> I[Output<br/>registered image, GeoTIFF, GeoJSON, CSV, metrics, verdict]
  I --> A
```

| Stage | Module | Libraries |
|---|---|---|
| Lunar input, source + reference | `pipeline.decode_image`, `geo.read_georef` | OpenCV, NumPy, GDAL |
| Preprocess | `pipeline.preprocess`, `match_at_scale` | OpenCV, scikit-image |
| AI correspondence | `engines.py` | PyTorch, Kornia, Hugging Face Transformers, OpenCV |
| Match verification | `pipeline.estimate_homography`, `uniform_subset` | OpenCV (USAC_MAGSAC), NumPy |
| Registration | `pipeline.warp_to_ref` | OpenCV |
| Sub-pixel refinement | `pipeline.refine_subpixel` | OpenCV, NumPy |
| Output | `pipeline.render_*`, `geo.py` | scikit-image (SSIM), GeoPandas, GDAL |

## Accuracy policy
Metrics are measured, never assumed. Error is reported on (a) matches held out from the fit and
(b) a patch-correlation grid not used for refinement. Pairs that fail verification return
`failed` or `review`, not a guessed alignment. The `/api/demo` tile has a known ground-truth transform.
