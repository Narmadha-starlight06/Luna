"""LUNA API. Run:  uvicorn main:app --port 8000   (serves the built React UI at /)"""
import os
from typing import List, Optional

import cv2
import numpy as np
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

import pipeline
import synthetic

app = FastAPI(title="LUNA — Lunar Unified Neural Alignment", version="1.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

MAX_BYTES = 120 * 1024 * 1024


async def _read(f: UploadFile) -> bytes:
    data = await f.read()
    if not data:
        raise HTTPException(400, f"'{f.filename}' is empty.")
    if len(data) > MAX_BYTES:
        raise HTTPException(413, f"'{f.filename}' is larger than 120 MB.")
    return data


@app.get("/api/health")
def health():
    return {"status": "ok", "opencv": cv2.__version__, "engines": pipeline.engine_status(), "stages": pipeline.STAGES}


@app.post("/api/register")
async def register(source: UploadFile = File(...), reference: UploadFile = File(...),
                   mode: str = Form("single"), engine: str = Form("auto"),
                   gsd_source: Optional[float] = Form(None), gsd_reference: Optional[float] = Form(None)):
    sb, rb = await _read(source), await _read(reference)
    try:
        res = pipeline.register_pair(sb, rb, mode, engine, gsd_source, gsd_reference, source.filename, reference.filename)
    except ValueError as e:
        raise HTTPException(422, str(e))
    return pipeline.to_payload(res)


@app.post("/api/register-multi")
async def register_multi(sources: List[UploadFile] = File(...), labels: List[str] = Form(...),
                         reference: UploadFile = File(...), gsd_reference: Optional[float] = Form(None),
                         engine: str = Form("auto")):
    if len(sources) != len(labels):
        raise HTTPException(400, "Each source needs a sensor label.")
    rb = await _read(reference)
    defs = [{"label": l, "bytes": await _read(f)} for f, l in zip(sources, labels)]
    try:
        return pipeline.register_multi(defs, rb, engine, gsd_reference)
    except ValueError as e:
        raise HTTPException(422, str(e))


@app.get("/api/demo")
def demo(sun_delta: float = 25.0, scale: float = 0.5, rotation: float = 14.0, el_src: float = 38.0, engine: str = "auto"):
    """Synthetic pair with known ground truth: reports true registration error."""
    src, ref, H = synthetic.make_pair(sun_delta=sun_delta, scale=scale, rotation=rotation, el_src=el_src)
    sb = cv2.imencode(".png", src)[1].tobytes()
    rb = cv2.imencode(".png", ref)[1].tobytes()
    res = pipeline.register_pair(sb, rb, "multiscale", engine, None, None, "demo-source", "demo-reference", truth_H=H)
    out = pipeline.to_payload(res)
    out["demo"] = {"sun_delta": sun_delta, "scale": scale, "rotation": rotation, "el_src": el_src}
    return out


_front = os.path.join(os.path.dirname(__file__), "..", "frontend", "dist")
if os.path.isdir(_front):
    app.mount("/", StaticFiles(directory=_front, html=True), name="ui")
