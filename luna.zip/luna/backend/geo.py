"""Geospatial layer: GDAL (georeference read, GeoTIFF write) and GeoPandas (match export).
Both are optional; without GDAL, outputs are in pixel coordinates."""
import base64
import json
import os
import tempfile
import uuid

import numpy as np


def read_georef(data: bytes, name: str):
    """(geotransform, wkt) of the file, or None."""
    try:
        from osgeo import gdal
    except Exception:
        return None
    p = f"/vsimem/{uuid.uuid4().hex}_{os.path.basename(name)}"
    gdal.FileFromMemBuffer(p, data)
    try:
        ds = gdal.Open(p)
        if ds is None:
            return None
        gt = ds.GetGeoTransform()
        if gt == (0.0, 1.0, 0.0, 0.0, 0.0, 1.0) or not ds.GetProjection():
            return None
        return gt, ds.GetProjection()
    finally:
        gdal.Unlink(p)


def pix2map(gt, x, y):
    return gt[0] + x * gt[1] + y * gt[2], gt[3] + x * gt[4] + y * gt[5]


def matches_geojson(matches, residuals, georef=None):
    """Verified matches as a GeoJSON FeatureCollection built with GeoPandas.
    Geometry is in the reference map CRS when georeferenced, else reference pixel space."""
    try:
        import geopandas as gpd
        from shapely.geometry import Point
    except Exception:
        return None
    m = np.asarray(matches, float).reshape(-1, 4)
    if georef:
        gt, wkt = georef
        xy = [pix2map(gt, x + .5, y + .5) for x, y in m[:, 2:4]]
        crs = wkt
    else:
        xy, crs = [(x, y) for x, y in m[:, 2:4]], None
    gdf = gpd.GeoDataFrame(
        {"src_x": m[:, 0], "src_y": m[:, 1], "ref_x": m[:, 2], "ref_y": m[:, 3], "residual_px": residuals},
        geometry=[Point(p) for p in xy], crs=crs)
    return gdf.to_json()


def registered_geotiff_b64(reg_u8, mask, georef, scale_to_full):
    """Registered image as a GeoTIFF on the reference grid (needs GDAL + georeferenced reference)."""
    if not georef:
        return None
    try:
        from osgeo import gdal
    except Exception:
        return None
    gt, wkt = georef
    f = scale_to_full  # working px -> original ref px is 1/f
    gt2 = (gt[0], gt[1] / f, gt[2] / f, gt[3], gt[4] / f, gt[5] / f)
    path = os.path.join(tempfile.gettempdir(), uuid.uuid4().hex + ".tif")
    drv = gdal.GetDriverByName("GTiff")
    h, w = reg_u8.shape
    ds = drv.Create(path, w, h, 2, gdal.GDT_Byte, options=["COMPRESS=DEFLATE"])
    ds.SetGeoTransform(gt2); ds.SetProjection(wkt)
    ds.GetRasterBand(1).WriteArray(reg_u8)
    ds.GetRasterBand(2).WriteArray((mask > 0).astype(np.uint8) * 255)
    ds.FlushCache(); ds = None
    try:
        with open(path, "rb") as fh:
            return base64.b64encode(fh.read()).decode()
    finally:
        os.remove(path)
