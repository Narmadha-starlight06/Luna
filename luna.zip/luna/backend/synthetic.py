"""Synthetic lunar terrain with a known ground-truth transform.

Used by /api/demo so registration accuracy can be measured against truth,
not just against the matcher's own inliers.
"""
import cv2
import numpy as np


def make_heightmap(n=1400, seed=7):
    rng = np.random.default_rng(seed)
    h = np.zeros((n, n), np.float32)
    for res, amp in [(6, 1.0), (14, .55), (30, .3), (64, .16), (128, .08), (256, .04)]:
        f = rng.standard_normal((res, res)).astype(np.float32)
        h += amp * cv2.resize(f, (n, n), interpolation=cv2.INTER_CUBIC)
    h *= 5.0
    for _ in range(520):
        u = rng.uniform(0.02, 1.0)
        r = float(np.clip(7.0 * u ** -0.75, 7, 230))
        cx, cy = rng.uniform(0, n, 2)
        d = 0.22 * r
        pad = int(r * 1.8) + 2
        x0, x1 = max(0, int(cx) - pad), min(n, int(cx) + pad)
        y0, y1 = max(0, int(cy) - pad), min(n, int(cy) + pad)
        if x1 <= x0 or y1 <= y0:
            continue
        yy, xx = np.mgrid[y0:y1, x0:x1].astype(np.float32)
        rr = np.hypot(xx - cx, yy - cy)
        bowl = np.where(rr < r, -d * (1 - (rr / r) ** 2), 0)
        rim = 0.30 * d * np.exp(-((rr - r) / (0.16 * r)) ** 2)
        h[y0:y1, x0:x1] += bowl + rim
    return h


def shade(h, azimuth_deg, elevation_deg, seed=0, noise=2.0):
    rng = np.random.default_rng(seed)
    gy, gx = np.gradient(h)
    az, el = np.radians(azimuth_deg), np.radians(elevation_deg)
    lx, ly, lz = np.cos(el) * np.sin(az), -np.cos(el) * np.cos(az), np.sin(el)
    lam = (-gx * lx - gy * ly + lz) / np.sqrt(1 + gx ** 2 + gy ** 2)
    img = np.clip(lam, 0, None)
    alb = cv2.resize(rng.normal(1, 0.06, (24, 24)).astype(np.float32), h.shape[::-1], interpolation=cv2.INTER_CUBIC)
    img = img * alb
    img = img / (np.percentile(img, 99.5) + 1e-6) * 235
    img = cv2.GaussianBlur(img, (0, 0), 0.8)
    img += rng.normal(0, noise, img.shape)
    return np.clip(img, 0, 255).astype(np.uint8)


def make_pair(sun_delta=40.0, scale=0.5, rotation=14.0, seed=7, el_ref=44.0, el_src=32.0):
    """Reference: whole tile at coarse resolution, sun from the east.
    Source: finer-resolution crop, rotated and slightly perspective-skewed,
    lit from a different azimuth/elevation. Returns (src, ref, H_true src->ref)."""
    n = 1400
    h = make_heightmap(n, seed)
    fine_ref = shade(h, 100, el_ref, seed=1)
    fine_src = shade(h, 100 + sun_delta, el_src, seed=2)
    ref = cv2.resize(fine_ref, (int(n * scale), int(n * scale)), interpolation=cv2.INTER_AREA)

    out = 760
    cx, cy = n * 0.52, n * 0.47
    rot = cv2.getRotationMatrix2D((cx, cy), rotation, 1.0)
    M = np.vstack([rot, [0, 0, 1]])
    persp = np.array([[1, 0, 0], [0, 1, 0], [2.2e-5, -1.6e-5, 1]], np.float64)
    shift = np.array([[1, 0, -(cx - out / 2)], [0, 1, -(cy - out / 2)], [0, 0, 1]], np.float64)
    # fine-frame -> source-frame; persp is applied around the crop centre
    c = np.array([[1, 0, out / 2], [0, 1, out / 2], [0, 0, 1]], np.float64)
    ci = np.linalg.inv(c)
    Msrc = c @ persp @ ci @ shift @ M
    src = cv2.warpPerspective(fine_src, Msrc, (out, out), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REFLECT)
    S = np.diag([scale, scale, 1.0])
    H_true = S @ np.linalg.inv(Msrc)
    H_true /= H_true[2, 2]
    return src, ref, H_true
