"""LUNA registration pipeline.

Stages (mirrors the system-flow diagram):
  input -> source+reference -> preprocess -> AI correspondence -> match verification
  -> geometric registration -> sub-pixel refinement -> output (metrics + evidence)

Accuracy is *measured and reported*, never assumed. A registration that fails
verification is returned with status "failed" and a reason instead of a guess.
"""
import base64
import math
import time
import uuid
from dataclasses import dataclass, field

import cv2
import numpy as np

MAX_DIM = 2200
GRID = 6  # coverage grid (GRID x GRID cells)

STAGES = [
    "Lunar input", "Source + reference", "Preprocess", "AI correspondence",
    "Match verification", "Registration", "Sub-pixel refinement", "Output",
]


# ----------------------------------------------------------------- input
def _gdal_read(data: bytes, name: str):
    from osgeo import gdal  # optional
    path = f"/vsimem/{uuid.uuid4().hex}_{name}"
    gdal.FileFromMemBuffer(path, data)
    try:
        ds = gdal.Open(path)
        if ds is None:
            return None
        b = ds.GetRasterBand(1)
        arr = b.ReadAsArray().astype(np.float32)
        nd = b.GetNoDataValue()
        if nd is not None:
            arr[arr == nd] = np.nan
        return arr
    finally:
        gdal.Unlink(path)


def decode_image(data: bytes, name: str = "img.png") -> np.ndarray:
    arr = None
    img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_UNCHANGED)
    if img is not None:
        if img.ndim == 3:
            img = img[:, :, :3]
            img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        arr = img.astype(np.float32)
    else:
        try:
            arr = _gdal_read(data, name)
        except Exception:
            arr = None
    if arr is None:
        raise ValueError(f"Could not read '{name}'. Use PNG, JPG, TIFF (16-bit ok) or a GDAL-readable file.")
    arr = np.nan_to_num(arr, nan=0.0)
    return arr


def stretch_u8(g: np.ndarray) -> np.ndarray:
    valid = g[g > 0] if (g > 0).mean() > 0.05 else g.ravel()
    lo, hi = np.percentile(valid, [0.5, 99.5])
    if hi - lo < 1e-6:
        hi = lo + 1
    return np.clip((g - lo) / (hi - lo) * 255, 0, 255).astype(np.uint8)


def to_working(g: np.ndarray):
    """Downscale for processing; returns (uint8 image, factor working/original)."""
    u8 = stretch_u8(g)
    m = max(u8.shape)
    f = 1.0
    if m > MAX_DIM:
        f = MAX_DIM / m
        u8 = cv2.resize(u8, None, fx=f, fy=f, interpolation=cv2.INTER_AREA)
    return u8, f


# ------------------------------------------------------------ preprocess
def flat_field(u8: np.ndarray) -> np.ndarray:
    """Remove low-frequency illumination, equalise local contrast."""
    g = u8.astype(np.float32) / 255.0
    sigma = max(g.shape) / 18.0
    hf = g - cv2.GaussianBlur(g, (0, 0), sigma)
    sd = np.sqrt(cv2.GaussianBlur(hf * hf, (0, 0), sigma / 3)) + 1e-3
    n = np.clip(hf / sd, -3, 3)
    out = ((n + 3) / 6 * 255).astype(np.uint8)
    return cv2.createCLAHE(2.0, (8, 8)).apply(out)


def structure_map(u8: np.ndarray) -> np.ndarray:
    """Sign-invariant structure (gradient magnitude): robust to shadow/contrast
    reversal between different sun azimuths and across sensors."""
    g = cv2.GaussianBlur(flat_field(u8).astype(np.float32), (0, 0), 1.2)
    gx = cv2.Sobel(g, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(g, cv2.CV_32F, 0, 1, ksize=3)
    mag = cv2.magnitude(gx, gy)
    hi = np.percentile(mag, 99)
    mag = np.clip(mag / (hi + 1e-6), 0, 1)
    return (np.sqrt(mag) * 255).astype(np.uint8)


def preprocess(u8: np.ndarray) -> dict:
    return {"norm": flat_field(u8), "mag": structure_map(u8)}


# ------------------------------------------------- correspondence engine
import engines  # noqa: E402
import geo  # noqa: E402


def engine_status() -> dict:
    return engines.status()


# ---------------------------------------------------------- verification
def valid_homography(H, w, h) -> bool:
    if H is None or not np.all(np.isfinite(H)):
        return False
    corners = np.float32([[0, 0], [w, 0], [w, h], [0, h]]).reshape(-1, 1, 2)
    t = cv2.perspectiveTransform(corners, H).reshape(-1, 2)
    if not np.all(np.isfinite(t)):
        return False
    area = cv2.contourArea(t.astype(np.float32))
    if area < 0.002 * w * h or area > 500 * w * h:
        return False
    return bool(cv2.isContourConvex(t.astype(np.float32).reshape(-1, 1, 2)))


def estimate_homography(P, Q, thr=3.0):
    if len(P) < 12:
        return None, np.zeros(len(P), bool)
    H, m = cv2.findHomography(P, Q, cv2.USAC_MAGSAC, thr, maxIters=10000, confidence=0.9995)
    if H is None or m is None:
        return None, np.zeros(len(P), bool)
    return H, m.ravel().astype(bool)


def uniform_subset(Q, bbox, per_cell=10, score=None):
    """Thin matches so no region dominates the fit (uniform spatial distribution)."""
    x0, y0, x1, y1 = bbox
    w, h = x1 - x0, y1 - y0
    cx = np.clip(((Q[:, 0] - x0) / w * GRID).astype(int), 0, GRID - 1)
    cy = np.clip(((Q[:, 1] - y0) / h * GRID).astype(int), 0, GRID - 1)
    cell = cy * GRID + cx
    keep = np.zeros(len(Q), bool)
    s = score if score is not None else np.zeros(len(Q))
    for c in np.unique(cell):
        idx = np.where(cell == c)[0]
        idx = idx[np.argsort(-s[idx])][:per_cell]
        keep[idx] = True
    return keep


def overlap_bbox(H, src_shape, ref_shape):
    h, w = src_shape
    c = cv2.perspectiveTransform(np.float32([[0, 0], [w, 0], [w, h], [0, h]]).reshape(-1, 1, 2), H).reshape(-1, 2)
    x0, y0 = np.clip(c.min(0), 0, [ref_shape[1], ref_shape[0]])
    x1, y1 = np.clip(c.max(0), 0, [ref_shape[1], ref_shape[0]])
    return float(x0), float(y0), float(max(x1, x0 + 1)), float(max(y1, y0 + 1))


def coverage(Q, bbox):
    x0, y0, x1, y1 = bbox
    w, h = x1 - x0, y1 - y0
    if len(Q) == 0:
        return 0.0, np.zeros((GRID, GRID), int)
    cx = np.clip(((Q[:, 0] - x0) / w * GRID).astype(int), 0, GRID - 1)
    cy = np.clip(((Q[:, 1] - y0) / h * GRID).astype(int), 0, GRID - 1)
    g = np.zeros((GRID, GRID), int)
    np.add.at(g, (cy, cx), 1)
    return float((g > 0).mean()), g


def scale_candidates(gsd_src, gsd_ref, mode):
    ladder = [1, 1 / 2, 1 / 4, 1 / 8, 1 / 16, 2, 4]
    if gsd_src and gsd_ref and gsd_src > 0 and gsd_ref > 0:
        prior = gsd_src / gsd_ref  # source pixels -> reference pixels
        near = [prior, prior * 0.8, prior * 1.25]
        return near + [s for s in ladder if all(abs(math.log(s / n)) > 0.3 for n in near)]
    return ladder


def match_at_scale(src_u8, ref_rep, s, engine='auto'):
    h, w = src_u8.shape
    nw, nh = int(round(w * s)), int(round(h * s))
    if min(nw, nh) < 160 or max(nw, nh) > 2600:
        return None
    interp = cv2.INTER_AREA if s < 1 else cv2.INTER_CUBIC
    sc = cv2.resize(src_u8, (nw, nh), interpolation=interp)
    rep = preprocess(sc)
    try:  # radiometric alignment of the source to the reference histogram (scikit-image)
        from skimage.exposure import match_histograms
        rep["norm"] = np.clip(match_histograms(rep["norm"], ref_rep["norm"]), 0, 255).astype(np.uint8)
    except Exception:
        pass
    P, Q, S, used, note = engines.correspond(rep, ref_rep, engine)
    H, inl = estimate_homography(P, Q, 3.0)
    return {"s": s, "H": H, "inl": inl, "P": P, "Q": Q, "S": S, "used": used, "note": note, "n": int(inl.sum())}


# ------------------------------------------------- sub-pixel refinement
def patch_shifts(reg, ref, mask, pts, half=32, min_resp=0.08):
    """Phase-correlation residuals between registered source and reference.
    Returns rows (x, y, dx, dy, response): feature at (x,y) in `reg` sits at (x+dx, y+dy) in `ref`."""
    H_, W_ = ref.shape
    win = cv2.createHanningWindow((2 * half, 2 * half), cv2.CV_32F)
    rows = []
    for x, y in pts:
        x0, y0 = int(round(x)) - half, int(round(y)) - half
        if x0 < 0 or y0 < 0 or x0 + 2 * half > W_ or y0 + 2 * half > H_:
            continue
        if mask[y0:y0 + 2 * half, x0:x0 + 2 * half].mean() < 0.98:
            continue
        a = reg[y0:y0 + 2 * half, x0:x0 + 2 * half].astype(np.float32)
        b = ref[y0:y0 + 2 * half, x0:x0 + 2 * half].astype(np.float32)
        if a.std() < 3 or b.std() < 3:
            continue
        (dx, dy), resp = cv2.phaseCorrelate(a, b, win)
        if resp < min_resp or abs(dx) > half / 2 or abs(dy) > half / 2:
            continue
        rows.append((x, y, dx, dy, resp))
    return np.array(rows, np.float32).reshape(-1, 5)


def check_points(shape, mask, offset=0.5, n=14, half=32):
    h, w = shape
    xs = (np.arange(n) + offset) / n * w
    ys = (np.arange(n) + offset) / n * h
    return [(x, y) for y in ys for x in xs]


def warp_to_ref(src_u8, H, ref_shape):
    h, w = ref_shape
    reg = cv2.warpPerspective(src_u8, H, (w, h), flags=cv2.INTER_CUBIC)
    mask = cv2.warpPerspective(np.full(src_u8.shape, 255, np.uint8), H, (w, h), flags=cv2.INTER_NEAREST) > 0
    mask = cv2.erode(mask.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(np.float32)
    return reg, mask


def residual_stats(rows):
    if len(rows) < 6:
        return None
    d = np.hypot(rows[:, 2], rows[:, 3])
    # drop gross outliers from the check set (mismatched textures), keep >= 80%
    keep = d <= np.percentile(d, 90)
    d = d[keep]
    return {"rmse": float(np.sqrt(np.mean(d ** 2))), "median": float(np.median(d)),
            "p95": float(np.percentile(d, 95)), "n": int(len(d))}


def ncc(a, b, m):
    sel = m > 0
    if sel.sum() < 100:
        return 0.0
    x, y = a[sel].astype(np.float32), b[sel].astype(np.float32)
    x -= x.mean(); y -= y.mean()
    return float((x * y).sum() / (np.sqrt((x * x).sum() * (y * y).sum()) + 1e-9))


def refine_subpixel(src_u8, ref_u8, ref_struct, H, iters=3):
    """Iterative dense patch-correlation refinement on sign-invariant structure maps.
    Fit on one sample grid, evaluate on an offset grid (independent check points)."""
    src_struct = structure_map(src_u8)
    shape = ref_u8.shape
    reg, mask = warp_to_ref(src_struct, H, shape)
    base_ncc = ncc(reg, ref_struct, mask)
    before = residual_stats(patch_shifts(reg, ref_struct, mask, check_points(shape, mask, 0.5)))
    best_H, best_ncc = H.copy(), base_ncc
    cur = H.copy()
    for it in range(iters):
        reg, mask = warp_to_ref(src_struct, cur, shape)
        rows = patch_shifts(reg, ref_struct, mask, check_points(shape, mask, 0.25, n=18))
        if len(rows) < 12:
            break
        q = rows[:, :2]
        D, inl = cv2.findHomography(q, q + rows[:, 2:4], cv2.RANSAC, 0.6, maxIters=3000)
        if D is None or inl.sum() < 10:
            break
        cand = D @ cur
        cand /= cand[2, 2]
        if not valid_homography(cand, *src_u8.shape[::-1]):
            break
        regc, maskc = warp_to_ref(src_struct, cand, shape)
        sc = ncc(regc, ref_struct, maskc)
        if sc >= best_ncc - 1e-4:
            best_H, best_ncc = cand, sc
        cur = cand
    reg, mask = warp_to_ref(src_struct, best_H, shape)
    after = residual_stats(patch_shifts(reg, ref_struct, mask, check_points(shape, mask, 0.5)))
    return best_H, {"before": before, "after": after, "ncc_before": base_ncc, "ncc_after": best_ncc}


# --------------------------------------------------------------- scoring
def confidence_score(inl, ratio, cov, resid_rmse):
    a = min(1.0, inl / 150.0)
    b = min(1.0, ratio / 0.5)
    c = cov
    d = 1.0 if resid_rmse is None else max(0.0, 1.0 - resid_rmse / 3.0)
    return round(100 * (0.25 * a + 0.2 * b + 0.25 * c + 0.3 * d), 1)


def verdict(inl, ratio, cov, resid):
    if inl < 15:
        return "failed", "Too few verified matches (%d). The pair may not overlap, or texture is too weak." % inl
    if resid is not None and resid["rmse"] > 6:
        return "failed", "Registration does not align on independent check points (residual %.1f px)." % resid["rmse"]
    if ratio < 0.12 or cov < 0.25:
        return "review", "Alignment found, but matches cover only part of the overlap. Review before using."
    if resid is not None and resid["rmse"] <= 1.0 and cov >= 0.5 and inl >= 40:
        return "verified", "Passed match verification and independent sub-pixel check."
    return "review", "Aligned, but residual error is above 1 px or coverage is limited."


# ----------------------------------------------------------- visualisation
def _b64(img, ext=".jpg", q=88):
    ok, buf = cv2.imencode(ext, img, [cv2.IMWRITE_JPEG_QUALITY, q] if ext == ".jpg" else [])
    return "data:image/%s;base64,%s" % ("jpeg" if ext == ".jpg" else "png", base64.b64encode(buf).decode())


def _fit(img, maxd=1100):
    s = min(1.0, maxd / max(img.shape[:2]))
    return cv2.resize(img, None, fx=s, fy=s, interpolation=cv2.INTER_AREA) if s < 1 else img


def render_matches(src_u8, ref_u8, P, Q, inl, H_scale_s):
    hs, ws = src_u8.shape
    hr, wr = ref_u8.shape
    th = 560
    ss, sr = th / hs, th / hr
    a = cv2.cvtColor(cv2.resize(src_u8, None, fx=ss, fy=ss), cv2.COLOR_GRAY2BGR)
    b = cv2.cvtColor(cv2.resize(ref_u8, None, fx=sr, fy=sr), cv2.COLOR_GRAY2BGR)
    canvas = np.zeros((th, a.shape[1] + b.shape[1] + 12, 3), np.uint8)
    canvas[:, :a.shape[1]] = a
    canvas[:, a.shape[1] + 12:] = b
    off = a.shape[1] + 12
    rng = np.random.default_rng(3)
    out_idx = np.where(~inl)[0]
    for i in rng.permutation(out_idx)[:50]:
        p = (int(P[i][0] * H_scale_s * ss), int(P[i][1] * H_scale_s * ss))
        q = (int(Q[i][0] * sr) + off, int(Q[i][1] * sr))
        cv2.line(canvas, p, q, (90, 90, 220), 1, cv2.LINE_AA)
    in_idx = np.where(inl)[0]
    for i in rng.permutation(in_idx)[:140]:
        p = (int(P[i][0] * H_scale_s * ss), int(P[i][1] * H_scale_s * ss))
        q = (int(Q[i][0] * sr) + off, int(Q[i][1] * sr))
        cv2.line(canvas, p, q, (230, 200, 70), 1, cv2.LINE_AA)
        cv2.circle(canvas, p, 3, (60, 160, 255), -1, cv2.LINE_AA)
        cv2.circle(canvas, q, 3, (60, 160, 255), -1, cv2.LINE_AA)
    return canvas


def render_checker(reg, ref, mask, tile=48):
    h, w = ref.shape
    yy, xx = np.mgrid[0:h, 0:w]
    chk = ((yy // tile + xx // tile) % 2 == 0) & (mask > 0)
    out = np.where(chk, reg, ref)
    return cv2.cvtColor(out, cv2.COLOR_GRAY2BGR)


def render_evidence(ref_u8, Qin, cov_grid, rows, bbox):
    bx0, by0, bx1, by1 = bbox
    w, h = bx1 - bx0, by1 - by0
    img = cv2.cvtColor(ref_u8, cv2.COLOR_GRAY2BGR)
    ov = img.copy()
    for gy in range(GRID):
        for gx in range(GRID):
            x0, x1 = int(bx0 + gx * w / GRID), int(bx0 + (gx + 1) * w / GRID)
            y0, y1 = int(by0 + gy * h / GRID), int(by0 + (gy + 1) * h / GRID)
            n = cov_grid[gy, gx]
            col = (60, 60, 200) if n == 0 else ((70, 170, 240) if n < 3 else (110, 190, 90))
            cv2.rectangle(ov, (x0, y0), (x1, y1), col, -1)
    img = cv2.addWeighted(ov, 0.22, img, 0.78, 0)
    for gx in range(1, GRID):
        cv2.line(img, (int(bx0 + gx * w / GRID), int(by0)), (int(bx0 + gx * w / GRID), int(by1)), (255, 255, 255), 1)
    for gy in range(1, GRID):
        cv2.line(img, (int(bx0), int(by0 + gy * h / GRID)), (int(bx1), int(by0 + gy * h / GRID)), (255, 255, 255), 1)
    for q in Qin[:600]:
        cv2.circle(img, (int(q[0]), int(q[1])), 2, (60, 160, 255), -1, cv2.LINE_AA)
    k = 12.0
    for x, y, dx, dy, r in rows:
        cv2.arrowedLine(img, (int(x), int(y)), (int(x + dx * k), int(y + dy * k)), (255, 230, 120), 2, cv2.LINE_AA, tipLength=0.35)
    return img


# ------------------------------------------------------------ main entry
@dataclass
class Result:
    status: str = "failed"
    message: str = ""
    H_full: np.ndarray = None
    reg: np.ndarray = None
    mask: np.ndarray = None
    ref_u8: np.ndarray = None
    metrics: dict = field(default_factory=dict)
    images: dict = field(default_factory=dict)
    matches: list = field(default_factory=list)
    stages: list = field(default_factory=list)
    ref_struct: np.ndarray = None
    geojson: str = None
    geotiff: str = None


def register_pair(src_bytes, ref_bytes, mode="single", engine="auto", gsd_src=None, gsd_ref=None,
                  src_name="source", ref_name="reference", truth_H=None):
    t0 = time.perf_counter()
    stages = []

    def mark(i):
        stages.append({"stage": STAGES[i], "ms": round((time.perf_counter() - mark.t) * 1000)})
        mark.t = time.perf_counter()
    mark.t = time.perf_counter()

    res = Result()
    # 1-2 input
    sg = decode_image(src_bytes, src_name); rg = decode_image(ref_bytes, ref_name)
    georef = geo.read_georef(ref_bytes, ref_name)
    mark(0)
    src_u8, fs = to_working(sg); ref_u8, fr = to_working(rg)
    mark(1)
    # 3 preprocess
    ref_rep = preprocess(ref_u8)
    mark(2)
    # 4 correspondence (scale-aware search)
    cands = scale_candidates(gsd_src, gsd_ref, mode)
    best, tried = None, []
    for s in cands:
        r = match_at_scale(src_u8, ref_rep, s, engine)
        if r is None:
            continue
        tried.append({"scale": round(float(s), 4), "inliers": r["n"]})
        if best is None or r["n"] > best["n"]:
            best = r
        ratio_c = r["n"] / max(1, len(r["P"]))
        if (mode != "multiscale" and r["n"] >= 60 and ratio_c >= 0.25) or (r["n"] >= 150 and ratio_c >= 0.3):
            break
    mark(3)
    if best is None or best["H"] is None or best["n"] < 12:
        res.message = "No reliable correspondence found at any tested scale."
        res.stages = stages
        res.metrics = {"status": "failed", "reason": res.message, "scale_search": tried}
        return res
    # 5 verification: uniform subset refit
    s = best["s"]
    P, Q, S, inl = best["P"], best["Q"], best["S"], best["inl"]
    Pin, Qin, Sin = P[inl], Q[inl], S[inl]
    Sm = np.diag([s, s, 1.0])
    bbox = overlap_bbox(best["H"] @ Sm, src_u8.shape, ref_u8.shape)
    keep = uniform_subset(Qin, bbox, 10, Sin)
    Hs, inl2 = estimate_homography(Pin[keep], Qin[keep], 2.0)
    if Hs is None or not valid_homography(Hs, *[int(round(v * s)) for v in src_u8.shape[::-1]]):
        Hs = best["H"]
    # holdout RMSE (fit on 80%, test on 20%)
    rng = np.random.default_rng(0)
    idx = rng.permutation(len(Pin))
    cut = int(0.8 * len(idx))
    hold = None
    if cut >= 12 and len(idx) - cut >= 4:
        Ht, _ = estimate_homography(Pin[idx[:cut]], Qin[idx[:cut]], 2.0)
        if Ht is not None:
            pr = cv2.perspectiveTransform(Pin[idx[cut:]].reshape(-1, 1, 2), Ht).reshape(-1, 2)
            hold = float(np.sqrt(np.mean(np.sum((pr - Qin[idx[cut:]]) ** 2, axis=1))))
    pr_all = cv2.perspectiveTransform(Pin.reshape(-1, 1, 2), Hs).reshape(-1, 2)
    fit_rmse = float(np.sqrt(np.mean(np.sum((pr_all - Qin) ** 2, axis=1))))
    cov, grid = coverage(Qin, bbox)
    mark(4)
    # 6 registration: scaled-source -> ref  composed with source scaling
    H0 = Hs @ Sm
    H0 /= H0[2, 2]
    reg0, mask0 = warp_to_ref(src_u8, H0, ref_u8.shape)
    mark(5)
    # 7 sub-pixel refinement
    ref_struct = ref_rep["mag"]
    H1, ref_info = refine_subpixel(src_u8, ref_u8, ref_struct, H0)
    reg, mask = warp_to_ref(src_u8, H1, ref_u8.shape)
    mark(6)
    # 8 outputs
    check_rows = patch_shifts(*(lambda r, m: (r, ref_struct, m))(*warp_to_ref(structure_map(src_u8), H1, ref_u8.shape)),
                              check_points(ref_u8.shape, mask, 0.5))
    resid = ref_info["after"]
    ratio = best["n"] / max(1, len(P))
    status, msg = verdict(best["n"], ratio, cov, resid)
    # decomposition of H into scale/rotation (affine part at image centre)
    cx, cy = src_u8.shape[1] / 2, src_u8.shape[0] / 2
    J = cv2.perspectiveTransform(np.float32([[[cx, cy]], [[cx + 1, cy]], [[cx, cy + 1]]]), H1).reshape(-1, 2)
    ex, ey = J[1] - J[0], J[2] - J[0]
    scale_est = float(math.sqrt(abs(ex[0] * ey[1] - ex[1] * ey[0])))
    rot_est = float(math.degrees(math.atan2(ex[1], ex[0])))
    # full-resolution homography (original pixel grids)
    S_src = np.diag([fs, fs, 1.0]); S_ref = np.diag([fr, fr, 1.0])
    H_full = np.linalg.inv(S_ref) @ H1 @ S_src
    H_full /= H_full[2, 2]
    mpp = (gsd_ref / fr) if gsd_ref else None  # metres per working pixel
    m = {
        "status": status, "message": msg, "engine": best["used"], "engine_note": best.get("note"),
        "georeferenced": bool(georef),
        "candidates": int(len(P)), "inliers": int(best["n"]), "inlier_ratio": round(ratio, 4),
        "coverage": round(cov, 3), "coverage_cells": f"{int((grid > 0).sum())}/{GRID * GRID}",
        "fit_rmse_px": round(fit_rmse, 3),
        "holdout_rmse_px": None if hold is None else round(hold, 3),
        "residual_rmse_px": None if resid is None else round(resid["rmse"], 3),
        "residual_median_px": None if resid is None else round(resid["median"], 3),
        "residual_p95_px": None if resid is None else round(resid["p95"], 3),
        "residual_before_refine_px": None if ref_info["before"] is None else round(ref_info["before"]["rmse"], 3),
        "check_points": 0 if resid is None else resid["n"],
        "ncc": round(ref_info["ncc_after"], 4), "ssim": None,
        "scale": round(scale_est, 4), "rotation_deg": round(rot_est, 2),
        "scale_search": tried,
        "confidence": confidence_score(best["n"], ratio, cov, None if resid is None else resid["rmse"]),
        "working_size": {"ref": list(ref_u8.shape[::-1]), "src": list(src_u8.shape[::-1])},
        "residual_rmse_m": None if (resid is None or mpp is None) else round(resid["rmse"] * mpp, 3),
        "H_full": H_full.round(8).tolist(),
    }
    try:  # scikit-image structural similarity on the overlap
        from skimage.metrics import structural_similarity
        ys, xs = np.where(mask > 0)
        if len(ys) > 400:
            y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
            m["ssim"] = round(float(structural_similarity(reg[y0:y1, x0:x1], ref_u8[y0:y1, x0:x1], data_range=255)), 3)
    except Exception:
        pass
    if truth_H is not None:
        gs = np.float32([[x, y] for y in np.linspace(0, src_u8.shape[0], 9) for x in np.linspace(0, src_u8.shape[1], 9)]).reshape(-1, 1, 2)
        a = cv2.perspectiveTransform(gs, H1).reshape(-1, 2)
        b = cv2.perspectiveTransform(gs, truth_H).reshape(-1, 2)
        e = np.hypot(*(a - b).T)
        m["ground_truth_rmse_px"] = round(float(np.sqrt(np.mean(e ** 2))), 3)
        m["ground_truth_max_px"] = round(float(e.max()), 3)
    # verified matches in ORIGINAL pixel coordinates, with per-match residual under the final model
    src_w = Pin / s
    proj = cv2.perspectiveTransform(src_w.reshape(-1, 1, 2), H1).reshape(-1, 2)
    resid_each = np.hypot(*(proj - Qin).T)
    order = np.argsort(resid_each)[:2000]
    res.matches = [[round(float(src_w[i][0] / fs), 2), round(float(src_w[i][1] / fs), 2),
                    round(float(Qin[i][0] / fr), 2), round(float(Qin[i][1] / fr), 2)] for i in order]
    res.geojson = geo.matches_geojson(res.matches, [round(float(resid_each[i]), 3) for i in order], georef)
    res.geotiff = geo.registered_geotiff_b64(np.where(mask > 0, reg, 0).astype(np.uint8), mask, georef, fr)
    res.images = {
        "reference": _b64(_fit(ref_u8)),
        "registered": _b64(_fit(np.where(mask > 0, reg, 0).astype(np.uint8)), ".png"),
        "checker": _b64(_fit(render_checker(reg, ref_u8, mask))),
        "matches": _b64(render_matches(src_u8, ref_u8, P, Q, inl, 1.0 / s)),
        "evidence": _b64(_fit(render_evidence(ref_u8, Qin, grid, check_rows, bbox))),
        "source": _b64(_fit(src_u8)),
    }
    mark(7)
    m["runtime_ms"] = round((time.perf_counter() - t0) * 1000)
    res.status, res.message, res.H_full, res.reg, res.mask, res.ref_u8 = status, msg, H_full, reg, mask, ref_u8
    res.ref_struct = ref_struct
    res.metrics, res.stages = m, stages
    return res


def to_payload(res: Result) -> dict:
    return {"status": res.status, "message": res.message, "metrics": res.metrics,
            "stages": res.stages, "images": res.images, "matches": res.matches,
            "geojson": res.geojson, "geotiff": res.geotiff}


# ----------------------------------------------------- multi-mission mode
def register_multi(sources, ref_bytes, engine="auto", gsd_ref=None):
    """sources: list of dict(label, bytes, gsd). Registers each to the reference,
    then measures cross-sensor agreement and basic terrain statistics."""
    layers = []
    for sdef in sources:
        r = register_pair(sdef["bytes"], ref_bytes, "multiscale", engine, sdef.get("gsd"), gsd_ref, sdef["label"])
        layers.append((sdef["label"], r))
    ok = [(l, r) for l, r in layers if r.status in ("verified", "review") and r.reg is not None]
    agreement = []
    for i in range(len(ok)):
        for j in range(i + 1, len(ok)):
            (la, ra), (lb, rb) = ok[i], ok[j]
            sa = structure_map(ra.reg); sb = structure_map(rb.reg)
            mk = ((ra.mask > 0) & (rb.mask > 0)).astype(np.float32)
            rows = patch_shifts(sa, sb, mk, check_points(sa.shape, mk, 0.5))
            st = residual_stats(rows)
            agreement.append({"pair": f"{la} vs {lb}", "residual_rmse_px": None if st is None else round(st["rmse"], 3),
                              "overlap": round(float(mk.mean()), 3)})
    terrain = []
    for l, r in ok:
        g = r.reg[r.mask > 0]
        if g.size == 0:
            continue
        shadow = float((g < np.percentile(g, 100) * 0.12).mean())
        e = cv2.Canny(r.reg, 60, 140)[r.mask > 0]
        terrain.append({"layer": l, "shadow_fraction": round(shadow, 3), "edge_density": round(float((e > 0).mean()), 4),
                        "mean_dn": round(float(g.mean()), 1)})
    fused = None
    if ok:
        chans = [r.reg for _, r in ok][:3]
        while len(chans) < 3:
            chans.append(chans[-1])
        base = ok[0][1].ref_u8
        fused = _b64(_fit(cv2.merge([chans[2], chans[1], chans[0]])))
    return {
        "layers": [{"label": l, **to_payload(r)} for l, r in layers],
        "agreement": agreement, "terrain": terrain, "fused": fused,
    }
