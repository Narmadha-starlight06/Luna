"""Correspondence engines.

  sift       RootSIFT + mutual ratio test (OpenCV)            always available
  loftr      Kornia LoFTR, detector-free transformer matcher  needs torch + kornia
  lightglue  Kornia DISK + LightGlue                          needs torch + kornia
  hf         Hugging Face EfficientLoFTR (transformers)       needs torch + transformers
  auto       best available learned engine fused with SIFT; falls back to SIFT

Learned engines run on a downscaled copy (sub-pixel accuracy comes from the refinement stage).
Every fallback is reported to the UI with its reason.
"""
import importlib.util
import os

import cv2
import numpy as np

LEARNED_SIDE = int(os.environ.get("LUNA_LEARNED_SIDE", 800))
HF_MODEL = os.environ.get("LUNA_HF_MODEL", "zju-community/efficientloftr")
_CACHE = {}


def _has(mod):
    return importlib.util.find_spec(mod) is not None


def status() -> dict:
    t = _has("torch")
    dev = "cpu"
    if t:
        try:
            import torch
            dev = "cuda" if torch.cuda.is_available() else "cpu"
        except Exception:
            t = False
    return {"sift": True, "torch": t, "device": dev,
            "loftr": t and _has("kornia"), "lightglue": t and _has("kornia"),
            "hf": t and _has("transformers"), "gdal": _has("osgeo"), "geopandas": _has("geopandas"),
            "skimage": _has("skimage")}


# ------------------------------------------------------------------ SIFT
def _rootsift(d):
    d = d / (d.sum(axis=1, keepdims=True) + 1e-7)
    return np.sqrt(d).astype(np.float32)


def sift(a, b, ratio=0.9):
    s = cv2.SIFT_create(nfeatures=4000, contrastThreshold=0.015, edgeThreshold=12)
    ka, da = s.detectAndCompute(a, None)
    kb, db = s.detectAndCompute(b, None)
    z = (np.zeros((0, 2), np.float32), np.zeros((0, 2), np.float32), np.zeros(0, np.float32))
    if da is None or db is None or len(ka) < 8 or len(kb) < 8:
        return z
    da, db = _rootsift(da), _rootsift(db)
    bf = cv2.FlannBasedMatcher(dict(algorithm=1, trees=6), dict(checks=96))
    ab = bf.knnMatch(da, db, k=2)
    back = {m[0].queryIdx: m[0].trainIdx for m in bf.knnMatch(db, da, k=1) if m}
    pa, pb, sc = [], [], []
    for pair in ab:
        if len(pair) < 2:
            continue
        m, n = pair
        if m.distance < ratio * n.distance and back.get(m.trainIdx) == m.queryIdx:
            pa.append(ka[m.queryIdx].pt); pb.append(kb[m.trainIdx].pt)
            sc.append(1 - m.distance / (n.distance + 1e-9))
    return np.float32(pa).reshape(-1, 2), np.float32(pb).reshape(-1, 2), np.float32(sc)


# --------------------------------------------------------- learned helpers
def _resize_side(x, side=LEARNED_SIDE, mult=8):
    s = min(1.0, side / max(x.shape))
    h, w = int(x.shape[0] * s) // mult * mult, int(x.shape[1] * s) // mult * mult
    h, w = max(h, mult * 8), max(w, mult * 8)
    return cv2.resize(x, (w, h), interpolation=cv2.INTER_AREA), (x.shape[1] / w, x.shape[0] / h)


def _device():
    import torch
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def loftr(a, b):
    import torch
    import kornia.feature as KF
    dev = _device()
    if "loftr" not in _CACHE:
        _CACHE["loftr"] = KF.LoFTR(pretrained="outdoor").to(dev).eval()
    ra, (sax, say) = _resize_side(a)
    rb, (sbx, sby) = _resize_side(b)
    ta = torch.from_numpy(ra)[None, None].float().div(255).to(dev)
    tb = torch.from_numpy(rb)[None, None].float().div(255).to(dev)
    with torch.no_grad():
        o = _CACHE["loftr"]({"image0": ta, "image1": tb})
    pa = o["keypoints0"].cpu().numpy() * [sax, say]
    pb = o["keypoints1"].cpu().numpy() * [sbx, sby]
    return pa.astype(np.float32), pb.astype(np.float32), o["confidence"].cpu().numpy().astype(np.float32)


def lightglue(a, b):
    import torch
    import kornia.feature as KF
    dev = _device()
    if "disk" not in _CACHE:
        _CACHE["disk"] = KF.DISK.from_pretrained("depth").to(dev).eval()
        _CACHE["lg"] = KF.LightGlue("disk").to(dev).eval()
    disk, lg = _CACHE["disk"], _CACHE["lg"]
    ra, (sax, say) = _resize_side(a, mult=16)
    rb, (sbx, sby) = _resize_side(b, mult=16)

    def feats(r):
        t = torch.from_numpy(cv2.cvtColor(r, cv2.COLOR_GRAY2RGB)).permute(2, 0, 1)[None].float().div(255).to(dev)
        with torch.no_grad():
            f = disk(t, n=3000, pad_if_not_divisible=True)[0]
        return f, torch.tensor([[r.shape[1], r.shape[0]]], device=dev)

    (fa, sza), (fb, szb) = feats(ra), feats(rb)
    with torch.no_grad():
        o = lg({"image0": {"keypoints": fa.keypoints[None], "descriptors": fa.descriptors[None], "image_size": sza},
                "image1": {"keypoints": fb.keypoints[None], "descriptors": fb.descriptors[None], "image_size": szb}})
    m = o["matches"][0].cpu().numpy()
    if len(m) == 0:
        return np.zeros((0, 2), np.float32), np.zeros((0, 2), np.float32), np.zeros(0, np.float32)
    ka, kb = fa.keypoints.cpu().numpy(), fb.keypoints.cpu().numpy()
    sc = o["scores"][0].cpu().numpy() if "scores" in o else np.ones(len(m))
    return (ka[m[:, 0]] * [sax, say]).astype(np.float32), (kb[m[:, 1]] * [sbx, sby]).astype(np.float32), sc.astype(np.float32)


def hf_efficientloftr(a, b):
    import torch
    from PIL import Image
    from transformers import AutoImageProcessor, AutoModelForKeypointMatching
    dev = _device()
    if "hf" not in _CACHE:
        _CACHE["hf"] = (AutoImageProcessor.from_pretrained(HF_MODEL),
                        AutoModelForKeypointMatching.from_pretrained(HF_MODEL).to(dev).eval())
    proc, model = _CACHE["hf"]
    ra, (sax, say) = _resize_side(a)
    rb, (sbx, sby) = _resize_side(b)
    ia, ib = Image.fromarray(ra).convert("RGB"), Image.fromarray(rb).convert("RGB")
    inputs = proc(images=[ia, ib], return_tensors="pt").to(dev)
    with torch.no_grad():
        out = model(**inputs)
    res = proc.post_process_keypoint_matching(out, [[(ra.shape[0], ra.shape[1]), (rb.shape[0], rb.shape[1])]], threshold=0.2)[0]
    pa = res["keypoints0"].cpu().numpy() * [sax, say]
    pb = res["keypoints1"].cpu().numpy() * [sbx, sby]
    return pa.astype(np.float32), pb.astype(np.float32), res["matching_scores"].cpu().numpy().astype(np.float32)


LEARNED = {"loftr": ("Kornia LoFTR", loftr), "lightglue": ("Kornia DISK + LightGlue", lightglue),
           "hf": ("Hugging Face EfficientLoFTR", hf_efficientloftr)}


def correspond(src_rep: dict, ref_rep: dict, engine: str = "auto"):
    """Returns (P_src, Q_ref, score, engine_label, note)."""
    st = status()
    P, Q, S, labels, note = [], [], [], [], None
    wanted = [engine] if engine in LEARNED else (["lightglue", "loftr", "hf"] if engine == "auto" else [])
    for key in wanted:
        if not st[key]:
            if engine != "auto":
                note = f"{LEARNED[key][0]} is not installed on this server; used SIFT instead."
            continue
        try:
            pa, pb, sc = LEARNED[key][1](src_rep["norm"], ref_rep["norm"])
            if len(pa) >= 20:
                P.append(pa); Q.append(pb); S.append(sc); labels.append(LEARNED[key][0])
                break
            note = f"{LEARNED[key][0]} found too few matches; added SIFT."
        except Exception as e:  # weights offline, OOM, API change
            note = f"{LEARNED[key][0]} unavailable ({type(e).__name__}); used SIFT instead."
    if engine in ("auto", "sift", "ensemble") or engine in LEARNED or not P:
        for k in ("norm", "mag"):
            pa, pb, sc = sift(src_rep[k], ref_rep[k])
            P.append(pa); Q.append(pb); S.append(sc)
        labels.append("RootSIFT")
    return np.vstack(P), np.vstack(Q), np.concatenate(S), " + ".join(labels), note
