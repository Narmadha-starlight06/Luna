const BASE = import.meta.env.VITE_API || ''

export async function api(path, opts) {
  let r
  try { r = await fetch(BASE + path, opts) }
  catch { throw new Error('Cannot reach the LUNA backend. Start it with: uvicorn main:app --port 8000') }
  if (!r.ok) {
    let m = `Request failed (${r.status})`
    try { const j = await r.json(); m = j.detail || m } catch {}
    throw new Error(m)
  }
  return r.json()
}

export const STAGES = ['Lunar input', 'Source + reference', 'Preprocess', 'AI correspondence',
  'Match verification', 'Registration', 'Sub-pixel refinement', 'Output']

export const VERDICT = { verified: 'Verified', review: 'Needs review', failed: 'Not registered' }
export const fmt = (v, d = 2) => (v == null ? '–' : Number(v).toFixed(d))
export const blobUrl = (txt, type) => URL.createObjectURL(new Blob([txt], { type }))
export const matchesCsv = (m) => 'source_x,source_y,reference_x,reference_y\n' + m.map(r => r.join(',')).join('\n')
export const dataUrl = (b64, type) => `data:${type};base64,${b64}`
