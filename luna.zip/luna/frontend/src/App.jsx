import { useCallback, useEffect, useState } from 'react'
import { api } from './api.js'
import Hero, { Ribbon } from './components/Hero.jsx'
import Workbench from './components/Workbench.jsx'
import Architecture from './components/Architecture.jsx'

export default function App() {
  const [health, setHealth] = useState(null)
  const [online, setOnline] = useState(null)
  const [metrics, setMetrics] = useState(null)
  const onMetrics = useCallback(m => setMetrics(m), [])

  useEffect(() => {
    api('/api/health').then(h => { setHealth(h); setOnline(true) }).catch(() => setOnline(false))
  }, [])

  return (
    <>
      <div className="wrap">
        <header className="top">
          <div className="brand">
            <svg viewBox="0 0 32 32" aria-hidden="true"><circle cx="16" cy="16" r="14" fill="#dcd8ce" /><path d="M16 2a14 14 0 0 0 0 28 9 14 0 0 1 0-28z" fill="#0f1a2c" opacity=".55" /><circle cx="11" cy="12" r="3" fill="#93a0b4" /><circle cx="19" cy="20" r="4" fill="#93a0b4" /><circle cx="21" cy="9" r="1.6" fill="#93a0b4" /></svg>
            LUNA
          </div>
          <span className="chip">
            <span className={'dot ' + (online ? 'on' : online === false ? 'off' : '')} />
            {online === null ? 'Connecting to backend' : online ? `Backend ready, OpenCV ${health.opencv}` : 'Backend offline'}
          </span>
        </header>
        <Hero online={online} onMetrics={onMetrics} />
        <Ribbon m={metrics} />
      </div>
      <Workbench engines={health?.engines} />
      <Architecture engines={health?.engines} />
      <div className="wrap"><footer>LUNA prototype for problem statement 26166. Metrics are in working-resolution pixels unless a ground sample distance is provided.</footer></div>
    </>
  )
}
