import { useMemo, useState } from 'react'
import { VERDICT, fmt, blobUrl, matchesCsv, dataUrl } from '../api.js'
import CompareSlider from './CompareSlider.jsx'

function Metrics({ m }) {
  const c = [
    ['Error on independent check points', `${fmt(m.residual_rmse_px)} px`, true],
    m.ground_truth_rmse_px != null && ['True error (known answer)', `${fmt(m.ground_truth_rmse_px)} px`, true],
    m.residual_rmse_m != null && ['Error on the ground', `${fmt(m.residual_rmse_m)} m`],
    ['Held-out match error', `${fmt(m.holdout_rmse_px)} px`],
    ['Fit error on matches', `${fmt(m.fit_rmse_px)} px`],
    ['Verified matches', `${m.inliers} of ${m.candidates}`],
    ['Inlier ratio', `${Math.round(m.inlier_ratio * 100)} %`],
    ['Overlap coverage', m.coverage_cells],
    ['Scale found', `${fmt(m.scale, 3)} ×`],
    ['Rotation found', `${fmt(m.rotation_deg, 1)} °`],
    ['Error before refinement', `${fmt(m.residual_before_refine_px)} px`],
    m.ssim != null && ['Structural similarity', fmt(m.ssim, 2)],
    ['Confidence score', `${fmt(m.confidence, 0)} / 100`],
  ].filter(Boolean)
  return <div className="metrics">{c.map(([k, v, h]) => <div key={k} className={'m' + (h ? ' hl' : '')}><div className="v">{v}</div><div className="k">{k}</div></div>)}</div>
}

const NOTES = {
  ov: 'Drag across the image. Left is the reference, right is your source warped onto it.',
  ck: 'Tiles alternate between reference and registered source. Craters and ridges should continue across tile edges.',
  mt: 'Blue lines are verified matches, red lines are rejected. Orange dots mark the matched features.',
  ev: 'Cells show how evenly matches cover the overlap (green is well covered, red is empty). Yellow arrows show leftover shifts, magnified 12 times, at check points that were not used for the fit.',
}

export function PairResult({ d }) {
  const [tab, setTab] = useState('ov')
  const m = d.metrics
  const links = useMemo(() => d.status === 'failed' ? null : ({
    csv: blobUrl(matchesCsv(d.matches), 'text/csv'),
    report: blobUrl(JSON.stringify({ metrics: m, stages: d.stages }, null, 2), 'application/json'),
    geojson: d.geojson ? blobUrl(d.geojson, 'application/geo+json') : null,
  }), [d, m])

  return (
    <>
      <div className={'verdict ' + d.status}><span className="badge">{VERDICT[d.status]}</span><p>{d.message || m.reason}</p></div>
      {m.engine && <p className="note-inline" style={{ color: 'var(--high)' }}>Engine: {m.engine}{m.engine_note ? <span style={{ color: 'var(--warn)' }}>. {m.engine_note}</span> : null}</p>}
      {d.status === 'failed' ? (
        <div className="card" style={{ marginTop: 14 }}>
          <p style={{ color: 'var(--high)' }}>Scales tried, with verified matches at each:</p>
          <table><thead><tr><th>Scale</th><th>Verified matches</th></tr></thead><tbody>{(m.scale_search || []).map(s => <tr key={s.scale}><td>{s.scale}×</td><td>{s.inliers}</td></tr>)}</tbody></table>
          <p style={{ marginTop: 12, color: 'var(--high)' }}>Try images with more overlap, or add the metres per pixel of each image so LUNA starts at the right scale.</p>
        </div>
      ) : (
        <>
          <Metrics m={m} />
          <div role="tablist" className="tabs">
            {[['ov', 'Overlay'], ['ck', 'Checkerboard'], ['mt', 'Matches'], ['ev', 'Evidence']].map(([k, t]) =>
              <button key={k} className="tab" role="tab" aria-selected={tab === k} onClick={() => setTab(k)}>{t}</button>)}
          </div>
          <div className="view">
            {tab === 'ov'
              ? <div className="stage"><CompareSlider left={d.images.reference} right={d.images.registered} leftLabel="Reference" rightLabel="Registered source" /></div>
              : <img alt={tab} src={d.images[{ ck: 'checker', mt: 'matches', ev: 'evidence' }[tab]]} />}
            <p className="note">{NOTES[tab]}</p>
          </div>
          <div className="dl">
            <a download="registered.png" href={d.images.registered}>Registered image</a>
            {d.geotiff && <a download="registered_geo.tif" href={dataUrl(d.geotiff, 'image/tiff')}>Registered GeoTIFF</a>}
            <a download="matches.csv" href={links.csv}>Match points (CSV)</a>
            {links.geojson && <a download="matches.geojson" href={links.geojson}>Match points (GeoJSON{m.georeferenced ? '' : ', pixel space'})</a>}
            <a download="report.json" href={links.report}>Report (JSON)</a>
          </div>
        </>
      )}
    </>
  )
}

export function MultiResult({ d }) {
  const [i, setI] = useState(0)
  return (
    <>
      <div className="layers" role="tablist">
        {d.layers.map((l, k) => <button key={l.label + k} className="tab" role="tab" aria-selected={i === k} onClick={() => setI(k)}>{l.label} ({VERDICT[l.status]})</button>)}
      </div>
      <div style={{ marginTop: 14 }}><PairResult key={i} d={d.layers[i]} /></div>
      {d.agreement.length > 0 && (
        <div className="card" style={{ marginTop: 16 }}>
          <h3 style={{ fontSize: 17 }}>Cross-sensor agreement</h3>
          <p style={{ color: 'var(--high)', marginTop: 6, fontSize: 14 }}>Residual shift between layers once both are registered to the reference. Small numbers mean the sensors agree.</p>
          <table><thead><tr><th>Pair</th><th>Residual</th><th>Shared area</th></tr></thead>
            <tbody>{d.agreement.map(a => <tr key={a.pair}><td>{a.pair}</td><td>{fmt(a.residual_rmse_px)} px</td><td>{Math.round(a.overlap * 100)}%</td></tr>)}</tbody></table>
        </div>
      )}
      {d.terrain.length > 0 && (
        <div className="card" style={{ marginTop: 16 }}>
          <h3 style={{ fontSize: 17 }}>Terrain statistics</h3>
          <table><thead><tr><th>Layer</th><th>Shadow</th><th>Edge density</th><th>Mean brightness</th></tr></thead>
            <tbody>{d.terrain.map(t => <tr key={t.layer}><td>{t.layer}</td><td>{(t.shadow_fraction * 100).toFixed(1)}%</td><td>{(t.edge_density * 100).toFixed(1)}%</td><td>{t.mean_dn}</td></tr>)}</tbody></table>
        </div>
      )}
      {d.fused && (
        <div className="card view" style={{ marginTop: 16 }}>
          <h3 style={{ fontSize: 17, marginBottom: 10 }}>Fused layers</h3>
          <img alt="Fused registered layers as red, green and blue channels" src={d.fused} />
          <p className="note">Each registered sensor becomes one colour channel. Colour fringes show where sensors disagree.</p>
        </div>
      )}
    </>
  )
}
