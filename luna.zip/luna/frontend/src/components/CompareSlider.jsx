import { useRef, useState } from 'react'

export default function CompareSlider({ left, right, leftLabel, rightLabel }) {
  const ref = useRef(null)
  const [p, setP] = useState(50)
  const clamp = v => Math.max(0, Math.min(100, v))
  const move = e => {
    const r = ref.current.getBoundingClientRect()
    setP(clamp(((e.clientX - r.left) / r.width) * 100))
  }
  return (
    <div
      ref={ref} className="cmp" style={{ '--p': p + '%' }} role="slider" tabIndex={0}
      aria-label={`Compare ${leftLabel} and ${rightLabel}`} aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(p)}
      onPointerDown={e => { e.currentTarget.setPointerCapture(e.pointerId); move(e) }}
      onPointerMove={e => { if (e.buttons) move(e) }}
      onKeyDown={e => { if (e.key === 'ArrowLeft') setP(clamp(p - 4)); if (e.key === 'ArrowRight') setP(clamp(p + 4)) }}
    >
      <img src={left} alt={leftLabel} />
      <img className="top-img" src={right} alt={rightLabel} />
      <div className="bar" />
      <div className="knob" aria-hidden="true">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><path d="M8 6l-5 6 5 6M16 6l5 6-5 6" /></svg>
      </div>
      <span className="tag l">{leftLabel}</span>
      <span className="tag r">{rightLabel}</span>
    </div>
  )
}
