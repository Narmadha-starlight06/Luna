import { useCallback, useEffect, useState } from 'react'
import { api, fmt } from '../api.js'
import CompareSlider from './CompareSlider.jsx'

const PRESETS = [
  { sun_delta: 25, rotation: 14, scale: 0.5, el_src: 38 },
  { sun_delta: 10, rotation: -18, scale: 0.45, el_src: 41 },
  { sun_delta: 30, rotation: 30, scale: 0.5, el_src: 36 },
  { sun_delta: 0, rotation: 7, scale: 0.6, el_src: 44 },
]

export default function Hero({ online, onMetrics }) {
  const [demo, setDemo] = useState(null)
  const [preset, setPreset] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [n, setN] = useState(0)

  const load = useCallback(async () => {
    const p = PRESETS[n % PRESETS.length]
    setN(n + 1); setLoading(true); setError('')
    try {
      const d = await api('/api/demo?' + new URLSearchParams(p))
      setDemo(d); setPreset(p); onMetrics(d.metrics)
    } catch (e) { setError(e.message) }
    setLoading(false)
  }, [n, onMetrics])

  useEffect(() => { if (online && !demo && !loading) load() }, [online]) // eslint-disable-line

  return (
    <div className="hero">
      <div>
        <h1>Line up any two views of the same lunar ground.</h1>
        <p className="lede">LUNA registers Chandrayaan-2 OHRC, TMC-2 and IIRS images to a lunar reference despite different sun angles and resolutions, and reports how accurate each result really is.</p>
        <div className="cta">
          <a className="btn" href="#bench" style={{ textDecoration: 'none' }}>Register your images</a>
          <button className="btn ghost" onClick={load} disabled={loading || !online}>Run another demo pair</button>
        </div>
        <div className="facts"><span>Scale, rotation and lighting handled together</span><span>Sub-pixel refinement with independent check points</span></div>
      </div>
      <div className="stage">
        {(!demo || loading) && (
          <div className="loading">
            <div>
              <div className="moon" />
              <div>{error || (online ? 'Registering a synthetic lunar tile with a known answer…' : <>Start the backend to see a live registration here:<br /><code>uvicorn main:app --port 8000</code></>)}</div>
            </div>
          </div>
        )}
        <div className="cmp-host">
          {demo && <CompareSlider left={demo.images.reference} right={demo.images.registered} leftLabel="Reference" rightLabel="Registered source" />}
        </div>
        <div className="cap">
          <span>{preset ? `Sun azimuth differs by ${preset.sun_delta}°, scale 1:${(1 / preset.scale).toFixed(1)}, rotation ${preset.rotation}°` : 'Drag to compare'}</span>
          <span>{demo?.metrics.ground_truth_rmse_px != null ? 'Measured against known truth' : ''}</span>
        </div>
      </div>
    </div>
  )
}

export function Ribbon({ m }) {
  if (!m || !m.inliers) return null
  const items = [
    [fmt(m.ground_truth_rmse_px) + ' px', 'true error against ground truth'],
    [fmt(m.residual_rmse_px) + ' px', 'error on independent check points'],
    [m.inliers, 'verified matches'],
    [Math.round(m.inlier_ratio * 100) + '%', 'inlier ratio'],
    [m.coverage_cells, 'overlap cells covered'],
    [(m.runtime_ms / 1000).toFixed(1) + ' s', 'runtime'],
  ]
  return <div className="ribbon" aria-live="polite">{items.map(([v, k]) => <div key={k}><div className="v">{v}</div><div className="k">{k}</div></div>)}</div>
}
