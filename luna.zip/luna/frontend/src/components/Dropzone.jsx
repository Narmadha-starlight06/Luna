import { useMemo, useState } from 'react'

export default function Dropzone({ title, hint, file, onFile, sensor, onSensor }) {
  const [over, setOver] = useState(false)
  const preview = useMemo(() => (file && /^image\/(png|jpe?g|webp|gif)$/.test(file.type) ? URL.createObjectURL(file) : null), [file])
  const take = f => { if (f) onFile(f) }
  return (
    <label className={'drop' + (over ? ' over' : '')}
      onDragOver={e => { e.preventDefault(); setOver(true) }} onDragLeave={() => setOver(false)}
      onDrop={e => { e.preventDefault(); setOver(false); take(e.dataTransfer.files[0]) }}>
      <div className="th" style={preview ? { backgroundImage: `url(${preview})` } : undefined}>{preview ? '' : file ? 'file' : 'image'}</div>
      <div className="t"><b>{title}</b><span>{file ? `${file.name} (${(file.size / 1048576).toFixed(1)} MB)` : hint}</span></div>
      {sensor && (
        <select value={sensor} aria-label={`Sensor for ${title}`} onClick={e => e.stopPropagation()} onChange={e => onSensor(e.target.value)}>
          {['OHRC', 'TMC-2', 'IIRS'].map(x => <option key={x}>{x}</option>)}
        </select>
      )}
      <input type="file" accept="image/*,.tif,.tiff,.img,.lbl,.jp2" onChange={e => take(e.target.files[0])} />
    </label>
  )
}
