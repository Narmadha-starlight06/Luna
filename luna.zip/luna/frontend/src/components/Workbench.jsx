import { useState } from 'react'
import { api } from '../api.js'
import Dropzone from './Dropzone.jsx'
import Pipeline from './Pipeline.jsx'
import { PairResult, MultiResult } from './Results.jsx'

const MODES = [
  ['single', 'Single image', 'Align a Chandrayaan-2 image to a lunar reference of the same terrain.'],
  ['multiscale', 'Multi-scale', 'Images at very different resolution. LUNA searches for the scale itself.'],
  ['multi', 'Multi-mission', 'OHRC, TMC-2 and IIRS against one reference, with a cross-sensor agreement check.'],
]
const ENGINES = [['auto', 'Auto (best available)'], ['sift', 'RootSIFT'], ['lightglue', 'Kornia DISK + LightGlue'], ['loftr', 'Kornia LoFTR'], ['hf', 'Hugging Face EfficientLoFTR']]

export default function Workbench({ engines }) {
  const [mode, setMode] = useState('single')
  const [source, setSource] = useState(null)
  const [reference, setReference] = useState(null)
  const [multi, setMulti] = useState([{ file: null, label: 'OHRC' }])
  const [gsrc, setGsrc] = useState('')
  const [gref, setGref] = useState('')
  const [engine, setEngine] = useState('auto')
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState('')
  const [result, setResult] = useState(null)
  const [stages, setStages] = useState(null)

  const switchMode = m => { setMode(m); setResult(null); setErr(''); setStages(null) }
  const setLayer = (i, patch) => setMulti(multi.map((s, k) => (k === i ? { ...s, ...patch } : s)))

  async function go(kind) {
    setErr(''); setResult(null); setStages(null)
    let path, opts
    if (kind === 'demo') {
      path = '/api/demo?sun_delta=20&rotation=-12&scale=0.5&el_src=39'
    } else {
      if (!reference) return setErr('Add the reference image.')
      const fd = new FormData()
      fd.append('engine', engine)
      if (mode === 'multi') {
        const srcs = multi.filter(s => s.file)
        if (!srcs.length) return setErr('Add at least one source image.')
        srcs.forEach(s => { fd.append('sources', s.file); fd.append('labels', s.label) })
        fd.append('reference', reference)
        if (gref) fd.append('gsd_reference', gref)
        path = '/api/register-multi'
      } else {
        if (!source) return setErr('Add the source image.')
        fd.append('source', source); fd.append('reference', reference); fd.append('mode', mode)
        if (gsrc) fd.append('gsd_source', gsrc)
        if (gref) fd.append('gsd_reference', gref)
        path = '/api/register'
      }
      opts = { method: 'POST', body: fd }
    }
    setBusy(true)
    try {
      const d = await api(path, opts)
      setStages(d.layers ? d.layers[0].stages : d.stages)
      setResult(d)
    } catch (e) { setErr(e.message) }
    setBusy(false)
  }

  const avail = k => k === 'auto' || k === 'sift' || (engines && engines[k])

  return (
    <section id="bench">
      <div className="wrap">
        <h2>Register a pair of your own</h2>
        <p className="sub">Choose a mode, add the images, and run. Accepted: PNG, JPG, TIFF (16-bit works) and, when GDAL is installed on the server, GeoTIFF and PDS files.</p>
        <div className="bench">
          <div className="card">
            <div className="modes">
              {MODES.map(([k, t, s]) => <button key={k} className="mode" aria-pressed={mode === k} onClick={() => switchMode(k)}><b>{t}</b><span>{s}</span></button>)}
            </div>
            <div className="drops">
              {mode === 'multi' ? (
                <>
                  {multi.map((s, i) => <Dropzone key={i} title={`Source ${i + 1}`} hint="Drop an image or tap to choose" file={s.file} onFile={f => setLayer(i, { file: f })} sensor={s.label} onSensor={l => setLayer(i, { label: l })} />)}
                  {multi.length < 3 && <button className="btn ghost" type="button" onClick={() => setMulti([...multi, { file: null, label: ['OHRC', 'TMC-2', 'IIRS'][multi.length] }])}>Add another sensor</button>}
                </>
              ) : <Dropzone title="Source image" hint="Chandrayaan-2 image to be moved" file={source} onFile={setSource} />}
              <Dropzone title={mode === 'multi' ? 'Lunar reference' : 'Reference image'} hint="Lunar reference it is aligned to" file={reference} onFile={setReference} />
            </div>
            <div className="opts">
              {mode !== 'multi' && <label>Source metres per pixel<input type="number" step="any" min="0" placeholder="optional" value={gsrc} onChange={e => setGsrc(e.target.value)} /></label>}
              <label>Reference metres per pixel<input type="number" step="any" min="0" placeholder="optional" value={gref} onChange={e => setGref(e.target.value)} /></label>
              <label style={{ gridColumn: '1 / -1' }}>Correspondence engine
                <select value={engine} onChange={e => setEngine(e.target.value)}>
                  {ENGINES.map(([k, t]) => <option key={k} value={k}>{t}{avail(k) ? '' : ' (not installed)'}</option>)}
                </select>
              </label>
            </div>
            <div className="row">
              <button className="btn" onClick={() => go('run')} disabled={busy}>{busy ? 'Registering…' : 'Run registration'}</button>
              <button className="btn ghost" onClick={() => go('demo')} disabled={busy}>Use demo pair</button>
            </div>
            <div className="err" role="alert">{err}</div>
          </div>
          <div>
            <Pipeline stages={stages} running={busy} />
            <div id="results">{result && (result.layers ? <MultiResult d={result} /> : <PairResult d={result} />)}</div>
          </div>
        </div>
      </div>
    </section>
  )
}
