const LAYERS = [
  ['React interface', ['Mode selector', 'Upload and options', 'Overlay, matches, evidence'], false],
  ['FastAPI service', ['/api/register', '/api/register-multi', 'Validation, GDAL/PDS decode'], false],
  ['AI correspondence', ['PyTorch', 'Kornia: LoFTR, DISK + LightGlue', 'Hugging Face: EfficientLoFTR'], true],
  ['Geometry and verification', ['OpenCV: SIFT, MAGSAC++, warping', 'scikit-image: histogram match, SSIM', 'NumPy: grid thinning, metrics'], true],
  ['Geospatial', ['GDAL: georeference, GeoTIFF', 'GeoPandas: match points as GeoJSON'], false],
  ['Evidence and output', ['Registered image', 'Match points and metrics', 'Confidence verdict'], false],
]
const FLOW = [
  ['Lunar input', 'Chandrayaan-2 OHRC, TMC-2 or IIRS image and a lunar reference are decoded and scaled for processing.'],
  ['Source and reference', 'The source is the moving image, the reference is the fixed one. Pixel sizes, if known, seed the scale search.'],
  ['Preprocess', 'Lighting is flattened and a sign-invariant structure map is built, so changed sun azimuth and elevation matter less.'],
  ['AI correspondence', 'A learned matcher (LoFTR, LightGlue, EfficientLoFTR) and RootSIFT find candidate matches at each scale hypothesis.'],
  ['Match verification', 'MAGSAC++ keeps geometrically consistent matches. Matches are thinned per grid cell and scored on a held-out set.'],
  ['Registration', 'The source is warped into the reference frame using the verified homography.'],
  ['Sub-pixel refinement', 'Patch correlation refines the alignment, then error is measured on check points that were never fitted.'],
  ['Output', 'Registered product, match points, RMSE, inlier count and ratio, coverage, and a verdict of verified, review or failed.'],
]
const STACK = ['PyTorch', 'Hugging Face', 'OpenCV', 'scikit-image', 'Kornia', 'NumPy', 'GDAL', 'GeoPandas', 'Python', 'React']

export default function Architecture({ engines }) {
  const on = k => engines && engines[k]
  return (
    <section id="architecture">
      <div className="wrap">
        <h2>Architecture and workflow</h2>
        <p className="sub">Six layers, from the browser to the registered product. The two highlighted layers do the matching and checking.</p>
        <div className="arch">
          {LAYERS.map(([t, items, hot]) => <div key={t} className={'layer' + (hot ? ' hot' : '')}><h3>{t}</h3><ul>{items.map(i => <li key={i}>{i}</li>)}</ul></div>)}
        </div>
        <div className="flow">
          {FLOW.map(([t, d], i) => <div className="step" key={t}><b>{i + 1}. {t}</b>{d}</div>)}
        </div>
        <div className="stack" aria-label="Technology stack">{STACK.map(s => <span key={s}>{s}</span>)}</div>
        {engines && (
          <p className="sub" style={{ marginTop: 18 }}>
            On this server: PyTorch {on('torch') ? `ready (${engines.device})` : 'not installed'}, Kornia matchers {on('loftr') ? 'ready' : 'not installed'}, Hugging Face {on('hf') ? 'ready' : 'not installed'}, GDAL {on('gdal') ? 'ready' : 'not installed'}, GeoPandas {on('geopandas') ? 'ready' : 'not installed'}. Missing engines fall back to RootSIFT and the result says so.
          </p>
        )}
      </div>
    </section>
  )
}
