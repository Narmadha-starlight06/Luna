import { useEffect, useState } from 'react'
import { STAGES } from '../api.js'

export default function Pipeline({ stages, running }) {
  const [tick, setTick] = useState(0)
  useEffect(() => {
    if (!running) return
    const t = setInterval(() => setTick(x => x + 1), 650)
    return () => clearInterval(t)
  }, [running])
  return (
    <div className="card">
      <h3 style={{ fontSize: 18, marginBottom: 14 }}>Pipeline</h3>
      <div className="pipe">
        {STAGES.map((s, i) => {
          const st = stages && stages[i]
          const cls = st ? 'done' : running && i === tick % 8 ? 'run' : ''
          return <div key={s} className={'node ' + cls}>{s}<span className="ms">{st ? st.ms + ' ms' : running ? 'working' : 'waiting'}</span></div>
        })}
      </div>
    </div>
  )
}
